﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Collections.Specialized;
using System.Diagnostics.CodeAnalysis;

namespace Test
{
    class Program
    {
        static void Task2(float length)
        {
            float area = length * length;
            Console.WriteLine("Length Of Square Is: "+area);
        }
        static void Task4()
        {
            for (int i = 0; i < 5; i++) { 
            
            Console.WriteLine("Welcome Jack!");
            }
        }  
        static void Task5(int number)
        {
            int sum = 0;
            while (number!= - 1)
            {
                sum += number;
                Console.Write("Enter Number: ");
#pragma warning disable CS8604 // Possible null reference argument.
                number=int.Parse(Console.ReadLine());
#pragma warning restore CS8604 // Possible null reference argument.
            }
            Console.Write("The Total Sum Is: {0}", sum);
        } 
        static void Task6(int number)
        {
            int sum = 0;
            do{
                sum += number;
                Console.Write("Enter Number: ");
#pragma warning disable CS8604 // Possible null reference argument.
                number=int.Parse(Console.ReadLine());
#pragma warning restore CS8604 // Possible null reference argument.
            }
            while (number != -1) ;
            Console.Write("The Total Sum Is: {0}", sum);
        }  
        static void Task7()
        {
            int[] numbers= new int[3];
            for(int i = 0; i < numbers.Length; i++)
            {
                Console.Write("Enter Number {0} ", i+1);
#pragma warning disable CS8604 // Possible null reference argument.
                numbers[i] = int.Parse(Console.ReadLine());
#pragma warning restore CS8604 // Possible null reference argument.
            }
            int greatest = -1000;
            for (int i = 0; i < numbers.Length; i++)
            {
                if (numbers[i] > greatest)
                {
                    greatest = numbers[i];
                }
            }
            Console.Write("The Greatest Numbers Is: {0}", greatest);


        }
        static void Task8()
        {
            float age, priceOfMachine, priceOfToy;
            Console.WriteLine("Enter Lily's Age: ");
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
            string str = Console.ReadLine();
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
#pragma warning disable CS8604 // Possible null reference argument.
            age = float.Parse(str);
#pragma warning restore CS8604 // Possible null reference argument.
            Console.WriteLine("Enter Price Of Washing Machine: ");
#pragma warning disable CS8604 // Possible null reference argument.
            priceOfMachine = float.Parse(Console.ReadLine());
#pragma warning restore CS8604 // Possible null reference argument.
            Console.WriteLine("Enter Price Of Each Unit Of Toy: ");
#pragma warning disable CS8604 // Possible null reference argument.
            priceOfToy = float.Parse(Console.ReadLine());
#pragma warning restore CS8604 // Possible null reference argument.
            int toyCount = 0;
            float money = 0;
            float totalMoney = 0;
            int brotherCount = 0;
            while (age != 0)
            {
                if (age % 2==0)
                {
                    money += 10;
                    totalMoney += money;
                    brotherCount++;
                }
                else
                {
                    toyCount++;
                }
                age--;
            }
            float total = (((toyCount * priceOfToy) + totalMoney) - brotherCount);
            if (total > priceOfMachine)
            {
                total-=priceOfMachine;
                Console.Write("YES! " + total);
            }
            else
            {
                total=priceOfMachine-total;
                Console.Write("NO! " + total);

            }

        }
        static void Task3(float marks)
        {
    
            if (marks > 50)
            {

            Console.WriteLine("You have passed ");
            }
            else
            {
                Console.WriteLine("You have failed");
            }
        }
        static void Task10()
        {

            string path = "D:\\OOP\\ConsoleApp1\\ConsoleApp1\\names.txt";
            if (File.Exists(path))
            {
                StreamReader fileVariable=new StreamReader(path);
                string record;
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
                while((record = fileVariable.ReadLine()) != null)
                {
                    Console.WriteLine(record);
                }
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
                fileVariable.Close();
            }
            else
            {
                    Console.WriteLine("File Does Not Exists");

            }
        } 
        static void Task11()
        {

            string path = "D:\\OOP\\ConsoleApp1\\ConsoleApp1\\titles.txt";
            StreamWriter file=new StreamWriter(path);
            file.WriteLine("SELAM!");
            file.Flush();
            file.Close();
        }
        static int menu()
        {
            int option;
            Console.WriteLine("1. Sign In");
            Console.WriteLine("2. Sign Up");
            Console.WriteLine("3. Exit");
            option = int.Parse(Console.ReadLine());
            return option;
        }
        static string parseData(string line,int field)
        {
            int comma = 1;
            string data = "";
            for(int i=0;i<line.Length;i++)
            {
                if (line[i] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    data += line[i];
                }
            }
            return data.Trim();
        }
        static void readData(string path,string[] names,string[] passwords)
        {
            int x = 0;
            if(File.Exists(path))
            {
                StreamReader file=new StreamReader(path);
                string line;
                while((line = file.ReadLine()) != null)
                {
                    names[x] = parseData(line, 1);
                    passwords[x] = parseData(line, 2);
                    x++;
                    if (x >= 5)
                    {
                        break;
                    }
                }
                file.Close();
               
            }
            else
            {
                Console.WriteLine("FILE NOT FOUND");
            }
        }
        static void signIn(string name,string password, string[] names, string[] passwords)
        {
            bool flag = false;
           for(int i = 0; i < 5; i++)
            {
                if (name == names[i]&& password == passwords[i])
                {
                    Console.WriteLine("VALID USER");
                    flag = true;
                }
              
            }
           if(flag==false)
            {
                    Console.WriteLine("INVALID USER");

            }
        }
        static void signUp(string path, string name,string password)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(name+","+password);
            file.Flush();
            file.Close();
        }
        static void Task1()
        {
            
            Console.WriteLine("Hello World!!!");
        }
        static int Task9(int number1,int number2)
        {
            int add = number1 + number2;
            return add;
        }
        static void pizzapoints(int order, int price)
        {
            string path = "D:\\OOP\\ConsoleApp1\\ConsoleApp1\\Customers.txt";
            StreamReader file = new StreamReader(path);
            //string name;
            //int noOrder;
            string line;
            while ((line = file.ReadLine()) != null)
            {
                string name=parseData(line,1);
                int noOrder = int.Parse(parseData(line, 2));
                //int noOrder;
                //if (!int.TryParse(parseData(line, 2), out noOrder))
                //{
                //    Console.WriteLine($"Invalid number of orders for {name}");
                //    continue;
                //}
                if (noOrder >= order)
                {
                    file.ReadLine();
                    int count = 0;
                    for (int i = 1; i <= noOrder; i++)
                    {
                        line = file.ReadLine();
                        int orderPrice = int.Parse(parseData(line, i+3));
                        //int orderPrice;
                        //if (!int.TryParse(parseData(line, i + 2), out orderPrice))
                        //{
                        //    Console.WriteLine($"Invalid price for order {i} for {name}");
                        //    continue;
                        //}
                        if (orderPrice >= price)
                        {
                            count++;
                        }
                    }
                    if (count >= order)
                    {
                        Console.WriteLine(name);
                    }
                }
            }
            file.Close();
        }
        static void Main(string[] args)
        {
            //Console.Write("Enter Length: ");
            ////string str;
            //float length = float.Parse(Console.ReadLine());
            //Console.Write("Enter Marks: ");
            ////string str;
            ////Task1();
            ////Task2(length);
            //Task3(marks);
            //Task4();
            //float marks = float.Parse(Console.ReadLine());
            //string str;
            //Console.Write("Enter Number1: ");
            //int number1 = int.Parse(Console.ReadLine());
            //Console.Write("Enter Number2: ");
            //int number2 = int.Parse(Console.ReadLine());
            //Task5(number);
            //Task6(number);
            //Console.WriteLine(Task9(number1,number2));
            //Task10();
            //Task11();
            // int option;
            //string path = "D:\\OOP\\ConsoleApp1\\ConsoleApp1\\textFile.txt";
            //string[] names = new string[5];
            //string[] passwords = new string[5];
            //int option = 1;
            //while (option < 3)
            //{
            //   readData(path, names, passwords);
            //   option = menu();
            //   if(option == 1)
            //   {
            //       //string name;
            //       //string password;
            //       Console.WriteLine("ENTER YOUR NAME: ");
            //       string name =Console.ReadLine();
            //       Console.WriteLine("ENTER YOUR PASSWORD: ");
            //       string password=Console.ReadLine();
            //       signIn(name, password, names, passwords); 
            //   }
            //   else if(option==2)
            //   {
            //       //string name;
            //       //string password;
            //       Console.WriteLine("ENTER YOUR NAME: ");
            //       string v = Console.ReadLine();
            //       string? name = v;
            //       Console.WriteLine("ENTER YOUR PASSWORD: ");
            //       string? password = Console.ReadLine();
            //       signUp(path, name, password);

            //   }
            //}
            //Console.WriteLine("Enter Order: ");
            //int order = int.Parse(Console.ReadLine());
            //Console.WriteLine("Enter Price: ");
            //int price = int.Parse(Console.ReadLine());
            int order = 8;
            int price = 15;
            pizzapoints(order, price);
            Console.ReadKey();
        }
    }
}